Bakery.draw = (function(B){
    if(typeof B === 'undefined'){
        console.error('[bakery.draw.js] you need load bakery.js before use baker.draw.js');
        return null;
    }
    var d = {}; //this 'd' will be Bakery.draw.

    d.Point = B.define({
        init:function (x, y) {
            var s = this;
            s.x(x)
                .y(y);
        },
        field:{
            x:0,
            y:0
        },
        property:{
            clone:function(){
                var s = this;
                return new d.Point(s.x(), s.y());
            },
            revertX:function(){
                var s = this;
                s.x(s.x() * -1);
                return s;
            },
            revertY:function(){
                var s = this;
                s.y(s.y() * -1);
                return s;
            },
            revert:function(){
                var s = this;
                return s.revertX().revertY();
            },
            toString:function(){
                var s = this;
                return '{x:' + s.x() + ',y:' + s.y() + '}';
            },
            add:function(point){
                var s = this;
                s.x(s.x() + point.x());
                s.y(s.y() + point.y());
                return s;
            },
            subtract:function(point){
                var s = this;
                s.x(s.x() - point.x());
                s.y(s.y() - point.y());
                return s;
            },
            distance:function(point){
                var s = this;
                var x = s.x() - point.x(),
                    y = s.y() - point.y();
                return Math.sqrt(
                    Math.pow(x, 2) + Math.pow(y, 2)
                );
            }
        }
    }).__extend__({
            random:function(area){
                var x = area.left() + area.getWidth() * Math.random(),
                    y = area.top() + area.getHeight() * Math.random();
                return new d.Point(x, y);
            }
        });

    d.Size = B.define({
        init:function(width, height){
            var s = this;
            s.width(width).height(height);
        },
        field:{
            width:0,
            height:0
        },
        property:{
            clone:function(){
                var s = this;
                return new d.Size(s.width(), s.height());
            },
            toString:function(){
                var s = this;
                return '{w:' + s.width() + ',h:' + s.height() + '}';
            }
        }
    });
    d.Area = B.define({
        init:function(top, right, bottom, left){
            var s = this;
            s
                .top(top || 0)
                .right(right || 0)
                .left(left || right || 0)
                .bottom(bottom || top || 0);
        },
        field:{
            left:0,
            top:0,
            right:0,
            bottom:0
        },
        property:{
            center:function(point){
                var s = this;
                if(!arguments.length) {
                    return new d.Point(
                        (s.right() + s.left()) / 2,
                        (s.top() + s.bottom()) / 2
                    );
                }
                var x = point.x(),
                    y = point.y(),
                    width = s.width(),
                    height = s.height();
                return s
                    .top(y - height / 2)
                    .right(x + width / 2)
                    .bottom(y + height / 2)
                    .left(x - width / 2);
            },
            width:function(width){
                var s = this;
                if(!arguments.length) return s.right() - s.left();
                var x = s.center().x();
                return s.left(x - width / 2)
                    .right(x + width / 2);
            },
            height:function(height){
                var s = this;
                if(!arguments.length) return s.bottom() - s.top();
                var y = s.center().y();
                return s.top(y - height / 2)
                    .bottom(y +  height / 2);
            },
            size:function(width, height){
                var s = this;
                if(!arguments.length) {
                    return new d.Size(s.width(), s.height());
                }
                var size = arguments[0] instanceof d.Size ?
                    arguments[0]:new d.Size(width, height);
                return s.width(size.width()).height(size.height());
            },
            toString:function(){
                var s = this;
                return '{top:' + s.top() + ',right:' + s.right()
                    +  ',bottom:' + s.bottom() + ',left:' + s.left()
            },
            clone:function(){
                var s = this;
                return new exports.Area(s.left(), s.top(), s.right(), s.bottom());
            },
            expand:function(amount){
                var s = this;
                s
                    .width(s.width() + amount)
                    .height(s.height() + amount);
                return s;
            },
            shrink:function(amount){
                var s = this;
                return s.expand(amount * -1);
            },
            contains:function(point){
                var s = this;
                var x = point.x(), y = point.y();
                return s.left() <= x
                    && x <= s.right()
                    && s.top() <= y
                    && y <= s.bottom();
            }

        }
    });
    return d;
})(Bakery);

Bakery.draw.color = (function (B) {

    var c = {}; // this 'c' will be Bakery.color
    c.RGBA = B.define({
        //r, g, b means  red, blue, green, 0 ~ 255.
        //a means alpha, 0.0 ~ 1.0
        init:function (r, g, b, a) {
            var s = this;
            s.r = r;
            s.g = g;
            s.b = b;
            s.a = a === undefined ? 1 : a;
        },
        property:{
            truncate:function () {
                var s = this;
                s.r = parseInt(s.r);
                s.g = parseInt(s.g);
                s.b = parseInt(s.b);
                return s;
            },
            toString:function () {
                var s = this;
                return 'rgba(' + s.r + ',' + s.g + ',' + s.b + ',' + s.a + ')';
            }
        }
    });
    c.RGB = B.define({
        prototype:c.RGBA,
        init:function (r, g, b) {
            var s = this;
            s.r = r;
            s.g = g;
            s.b = b;
            s.a = 1;
        }
    });
    c.HSV = B.define({
//h means hue, 0 ~ 360
        //s, v means saturation, value of brgitness, 0 ~ 100
        init:function (h, s, v) {
            var ss = this;
            ss.h = h;
            ss.s = s;
            ss.v = v;
        },
        property:{
            toRGBA:function () {
                var ss = this;
                //r, g, b means  red, blue, green, 0 ~ 255.
                //a means alpha, 0.0 ~ 1.0
                //h means hue, 0 ~ 360
                //s, v means saturation, value of brgitness, 0 ~ 100
                var rgb = (function (h, s, v) {
                    if (s == 0) return  new c.RGB(v, v, v);//gray
                    h = h % 360;
                    var i = Math.floor(h / 60);
                    var f = h / 60 - i;
                    v = v * 255 / 100;
                    var m = v * (1 - s / 100);
                    var n = v * (1 - s / 100 * f);
                    var k = v * (1 - s / 100 * (1 - f));
                    switch (i) {
                        case 0:
                            return new c.RGBA(v, k, m);
                        case 1:
                            return new c.RGBA(n, v, m);
                        case 2:
                            return new c.RGBA(m, v, k);
                        case 3:
                            return new c.RGBA(m, n, v);
                        case 4:
                            return new c.RGBA(k, m, v);
                        case 5:
                            return new c.RGBA(v, m, n);
                    }
                    return null;
                })(ss.h, ss.s, ss.v);
                rgb.truncate();
                return rgb;

            },
            toString:function (asHSV) {
                var ss = this;
                if (asHSV) return 'hsv(' + ss.h + ',' + ss.s + ',' + ss.v + ')';
                return ss.toRGBA().toString();
            },
            clone:function () {
                var ss = this;
                return new HSV(ss.h, ss.s, ss.v);
            },
            addHue:function (hue) {
                var ss = this;
                ss.h += hue;
                return ss;
            },
            addSaturation:function (saturation) {
                var ss = this;
                ss.s += saturation;
                return ss;
            },
            addBrightness:function (brightness) {
                var ss = this;
                ss.v += brightness;
                return ss;
            }
        }
    });

    return c;
})(Bakery);

Bakery.draw.Animation = (function(B){
    var requestAnimationFrame = (function(){
        if(typeof window === 'undefined') return;
        return window.requestAnimationFrame    ||
            window.webkitRequestAnimationFrame ||
            window.mozRequestAnimationFrame    ||
            window.oRequestAnimationFrame      ||
            window.msRequestAnimationFrame     ||
            function( callback ){
                window.setTimeout(callback, 1000 / 60);
            };
    })();
    return B.define({
        init:function(canvas, render){
            var s = this;
            s.render(render);
            s.canvas(canvas);
            s.renderables = [];
        },
        field:{
            render:null,
            frameCount:0,
            pausing:false,
            stopped:false,
            canvas:null
        },
        property:{
            add:function(renderable){
                var s = this;
                if(renderable instanceof Array){
                    renderable.forEach(function(renderable){
                        s.add(renderable);
                    });
                    return s;
                }
                s.renderables.push(renderable);
                return s;
            },
            remove:function(renderable){
                var s = this;
                if(renderable instanceof Array){
                    renderable.remove(function(renderable){
                        s.add(renderable);
                    });
                    return s;
                }
                var length = s.drawables.length;
                if(!length) return s;
                for(var i=0; i< length; i++){
                    var hit = s.drawables[i] === renderable;
                    if(hit){
                        s.renderables.splice(i, 1);
                        return s;
                    }
                }
                return s;
            },
            start:function(){
                var s = this,
                    canvas = s.canvas(),
                    ctx = canvas.getContext('2d');

                var executeRender = function(){
                    if(s.stopped()) return;
                    requestAnimationFrame.call(window, executeRender);
                    if(s.pausing()) return;
                    var frameCount = s.frameCount();
                    frameCount ++;

                    ctx.save();
                    var size = new B.draw.Size(canvas.width, canvas.height);


                    ctx.clearRect(0, 0, canvas.width, canvas.height);

                    for(var i=0; i< s.renderables.length; i++){
                        var renderable = s.renderables[i];
                        renderable.move && renderable.move.call(renderable);
                        renderable.draw && renderable.draw.call(renderable, ctx);
                    }

                    s.render().call(s, ctx, size, frameCount);

                    ctx.restore();
                    s.frameCount(frameCount);
                };
                executeRender();
            },
            stop:function(){
                var s = this;
                s.stoped = true;
                s.frameCount = 0;
            },
            pause:function(){
                var s = this;
                s.pausing = true;
            },
            resume:function(){
                var s = this;
                s.pausing = false;
            }
        }
    }).__extend__({
        requestAnimationFrame:requestAnimationFrame
    });
})(Bakery);

Bakery.draw.drawable = (function (B) {

    var HSV = B.draw.color.HSV,
        Point = B.draw.Point,
        Size = B.draw.Size;

    var d = {}; //this 'd' will be Bakery.draw.drawable.
    d.Drawable = B.define({
        field:{
            strokeColor:new HSV(200, 100, 100),
            fillColor:new HSV(20, 100, 100)
        },
        property:{
            _point:new Point(0, 0),
            _size:new Size(100, 100),
            point:function(x, y){
                var s = this;
                if(!arguments.length) return s._point;
                if(arguments[0] instanceof Point){
                    s._point = arguments[0];
                } else {
                    s._point = new Point(x, y);
                }
                return s;
            },
            size:function(width, height){
                var s = this;
                if(!arguments.length) return s._size;
                if(arguments[0] instanceof Size){
                    s._size = arguments[0];
                } else {
                    s._size = new Size(width, height);
                }
                return s;
            },
            draw:null
        }
    });
    d.Rectangle = B.define({
        prototype:d.Drawable,
        property:{
            draw:function (ctx) {
                var s = this;
                var area = new B.draw.Area().center(s.point())
                    .size(s.size());
                ctx.fillStyle = s.fillColor().toString();
                ctx.fillRect(
                    area.left(),
                    area.top(),
                    area.size().width(),
                    area.size().height()
                );
                return s;
            }
        }
    });
    d.Circle = B.define({
        prototype:d.Drawable,
        field:{
            fillColor:new HSV(20, 20, 100)
        },
        property:{
            _radius:100,
            radius:function(radius){
                var s = this;
                if(!arguments.length) return s._radius;
                s._radius = radius;
                s.size(new Size(radius, radius));
                return s;
            },
            draw:function(ctx){
                var s = this,
                    point = s.point(),
                    radius = s.radius();
                ctx.beginPath();
                ctx.fillStyle = s.fillColor().toString();
                ctx.arc(point.x(), point.y(), radius, 0, Math.PI * 2, false);
                ctx.fill();
                ctx.closePath();
                return s;
            }
        }
    });
    return d;
})(Bakery);

Bakery.draw.move = (function (B) {

    var Point = B.draw.Point

        ;

    var m = {}; // this 'm' will be Bakery.move;
    m.Velocity = B.define({
        prototype:Point,
        init:function (x, y) {
            var s = this;
            s.x(x).y(y);
        },
        property:{
            toString:function () {
                var s = this;
                return '{vx:' + s.x() + ',vy:' + s.y() + '}';
            },
            amount:function(){
                var s = this;
                return Math.sqrt(Math.pow(s.x(), 2) + Math.pow(s.y(), 2));
            },
            normalize:function(){
                var s = this;
                var amount = s.amount();
                if(!amount) return s;
                return s.multify(1 / amount);
                return s;
            },
            multify:function(amount){
                var s = this;
                s.x(s.x() * amount);
                s.y(s.y() * amount);
                return s;
            },
            clone:function(){
                var s = this;
                return new m.Velocity(s.x(), s.y());
            }
        }
    });

    m.Move = new B.Mixin({
        _velocity:new m.Velocity(0.4, 0.4),
        velocity:function(x, y){
            var s = this;
            if(!arguments.length) return s._velocity;
            s._velocity = arguments[0] instanceof m.Velocity?
                arguments[0] : new m.Velocity(x, y);
            return s;
        },
        move:function(point){
            var s = this;
            if(point) return s.point(point);
            if(s.pause()) return s;
            s.point().add(s.velocity());
            return s;
        }
    }).__field__({
            pause:false
        });


    return m;
})(Bakery);

