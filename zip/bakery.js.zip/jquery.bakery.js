/*
 * jquery.bakery.js v1.0.0
 *
 * Copyright (c) 2012 Taka Okunishi
 *
 * http://techbakery.net
 */
(function($){

})(jQuery);





